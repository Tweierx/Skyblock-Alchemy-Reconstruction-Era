// Create × Alchemistry 最终无错联动
ServerEvents.recipes(event => {
    const create = event.recipes.create;
    // 1. Alchemistry分解仪（仅用Create核心部件）
    create.mechanical_crafting('alchemistry:dissolver', [
       "hhhhdhhhh",
       "hjjjjjjjh",
       "hjbtttbjh",
       "hjttzttjh",
       "hjtzsztjh",
       "hjttzttjh",
       "hjbtttbjh",
       "hjjjjjjjh",
       "hhhhhhhhh"
    ], {
        h:'create:brass_ingot',
        d:'create:mechanical_press',
        j: 'create:precision_mechanism',
        b:'tconstruct:clear_glass',
        t:'minecraft:iron_block',
        z:'minecraft:diamond',
        s:'exdeorum:diamond_mesh'
    }).id('tweier:alchemistry/dissolver');

    // 2. Create蒸汽引擎（仅用Alchemistry核心燃料）
    event.shaped('create:steam_engine', [
        'ABA',
        'CDC',
        'ABA'
    ], {
        A: 'create:brass_ingot',
        B: 'alchemistry:chemical_fuel',
        C: 'minecraft:iron_ingot',
        D: 'create:engine_piston'
    }).id('tweier:create/steam_engine');
});

// 移除所有可能出错的材料互通配方，仅保留核心机器联动