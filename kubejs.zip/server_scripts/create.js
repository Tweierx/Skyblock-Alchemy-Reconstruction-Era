ServerEvents.recipes(event => {
    // 统一声明常量（仅声明1次，避免重复）
    const create = event.recipes.create;
    const incomplete = 'create:incomplete_precision_mechanism';

    // 1. C元素 - 石墨（研磨配方：修正参数顺序+概率输出语法）
    create.milling(
        Item.of('chemlib:carbon',8).withChance(0.2), // 第一个参数：输出物品
        Item.of("minecraft:oak_log"), // 第二个参数：输入物品
    ) 
    .id('tweier:carbonn'); // 修正ID拼写：carbonn→carbon

    // 2. 动力锯 - 切割配方（保留正确写法，补充分号）
    create.cutting(
        Item.of('minecraft:charcoal', 9), // 输出
        Item.of('thermal:charcoal_block') // 输入：数量1可省略
    )
    .processingTime(20 * 5) // 处理时间100ticks（5秒）
    .id('tweier:charcoal'); // 最终修正ID拼写：charcol→charcoal

    // 3. 动力辊压机 - 木炭块合成（保留正确写法，补充分号）
    create.compacting(
        Item.of('thermal:charcoal_block'), // 输出
        Item.of('minecraft:charcoal', 9) // 输入
    )
    .id('tweier:charcoal_block');

    // 4. 动力辊压机 - 螺旋桨配方（简化冗余的数量1，补充分号）
    create.compacting(
        Item.of('create:propeller'), // 输出
        [
            Item.of('create:iron_sheet', 4),
            Item.of('minecraft:iron_ingot') // 数量1省略
        ]
    )
    .id('tweier:propeller');

    // 5. 安山合金 - 动力搅拌器配方（简化冗余的数量1，补充分号）
    create.mixing(
        Item.of('create:andesite_alloy'), // 输出
        [
            Item.of('minecraft:andesite'), // 输入
            Item.of('minecraft:iron_nugget'), // 输入
            Fluid.of('minecraft:lava', 100) // 流体（100mb熔岩）
        ]
    )
    .id('tweier:andesite_alloy_mixing');
});



