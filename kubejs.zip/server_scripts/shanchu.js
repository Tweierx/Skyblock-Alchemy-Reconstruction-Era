     // 移除原版配方
 ServerEvents.recipes(event =>{
 event.remove({output:'exdeorum:oak_sieve'})
 event.remove({output:'minecraft:charcoal'})
 event.remove({output:'minecraft:furnace'})
 event.remove({output:'minecraft:campfire'})
event.remove({output:"#exdeorum:barrels"})
event.remove({output:'minecraft:composter'})
event.remove({output:'thermal:charcoal_block'})
  event.remove({output:'exdeorum:porcelain_crucible'})
  event.remove({output:'exdeorum:unfired_porcelain_crucible'})
  event.remove({output:'create:propeller'})
  event.remove({output:'create:andesite_alloy'})
   event.remove({output:'alchemistry:dissolver'})
    event.remove({output:'alchemistry:combiner'})

 })