// Create × Alchemistry 最终无错联动
ServerEvents.recipes(event => {
    // 1. Alchemistry分解仪（仅用Create核心部件）
    event.shaped('alchemistry:dissolver', [
        'ABA',
        'CDC',
        'ABA'
    ], {
        A: 'create:brass_ingot',
        B: 'create:brass_gear',
        C: 'minecraft:glass',
        D: 'create:precision_mechanism'
    }).id('tweier:alchemistry/dissolver');

    // 2. Create蒸汽引擎（仅用Alchemistry核心燃料）
    event.shaped('create:steam_engine', [
        'ABA',
        'CDC',
        'ABA'
    ], {
        A: 'create:brass_ingot',
        B: 'alchemistry:chemical_fuel',
        C: 'minecraft:iron_ingot',
        D: 'create:engine_piston'
    }).id('tweier:create/steam_engine');
});

// 移除所有可能出错的材料互通配方，仅保留核心机器联动