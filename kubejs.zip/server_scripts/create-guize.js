
//ServerEvents.recipes(event =>{
    //const create = event.recipes.create
//动力辊压机
    //create.compacting("输入","输出")
 //加热
 // create.compacting("输入","输出").heated()
  //超级加热
  // create.compacting("输入","输出").superheated()
  //流体
  //create.compacting(Fluid.ID(桶,1000 1桶),Fluid.ID())
  //概率
  // create.compacting([物品id,Item.of("id").withChance(概率(0.1-1))])
  //压片，也支持概率
  // create.pressing("输出物品","输入物品")



  //搅拌机
  //支持多个输入也支持概率，并且支持加热
  //create.mixing("输出物品",[Fluid.getId(液体),"输入物品"])



  //鼓风机
  //洗涤,支持多个输入也支持概率，并且支持加热
//create.splashing("输出","输入")
//灵魂火，同样支持
//create.haunting(Item.of("输出","输入"))


//石墨
//支持多个输入结果和概率输出
//create.milling(Item.of("输出","输入"))



//粉碎论
//支持多个输入结果和概率输出,支持添加处理时间
//create.crushing('输出', '输入').processingTime(20*秒)

//注液器
//create.filling('输出',['输入',Fluid.of('流体',500)])

//分液池
//create.emptying([Fluid.流体(50),'输出'],'输入')

//动力据
//支持多个输入结果和概率输出,支持添加处理时间
//create.cutting('输出','输入')


//机械手，如加不消耗物品最后写上.keepHeldItem()
//create.deploying('输出',['（要安装的）输入','(被安装的)输入'])

//砂纸,支持概率.withChance(概率(0.1-1)
//create.sandpaper_polishing('输出','输入')

//动力合成器,最大支持9*9
/*create.mechanical_crafting('输出',
[
    "AAAAA",
    "AAAAA",
    "AAAAA",
    "AAAAA",
    "AAAAA"

],
{
    A:"id",
})*/
/*//序列组装
const incomplete = 'tweier:diamond'
const incomplete = 'create:incomplete_precision_mechanism'

create.sequenced_assembly(
    [
        Item.of("输出物品").withChance(0.02)//<-概率，0.01-1，可以多个
    ],
    'minecraft:deepslate',
    [
        //参与机器-机械手
        create.deploying(incomplete,[incomplete,'id']).keepHeldItem(),
        //参与机器--切石
        create.cutting(incomplete,incomplete),
        //参与机器--注液器
        create.filling(incomplete,[incomplete,Fluid.lava(100)]),
        //参与机器--压片
        create.pressing(incomplete,incomplete)
    ]
)
//中间件--加工成的半成品物品
  .transitionalItem(incomplete)
  //循环次数，不写默认5次
  .loops(3)
*/
//})