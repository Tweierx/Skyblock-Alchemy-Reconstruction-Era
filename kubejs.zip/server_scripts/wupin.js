ServerEvents.recipes(event =>{
//筛子
    event.shaped(Item.of('exdeorum:oak_sieve',1),[
        '   ',
        "WWW",
        "S S"
    ],{
        W:'minecraft:oak_planks',
        S: 'minecraft:stick'
    }).id("tweier:sieve");
//木炭
        event.shaped(
        Item.of('minecraft:charcoal',1),
    [
        "CCC",
        "C C",
        "CCC"
    ],
    {
        C:'chemlib:carbon',
    }).id("tweier:charcoal_crafting");

//熔炉
    event.shaped(
        Item.of('minecraft:furnace', 1), // ① 修正物品ID + 补充分隔符
        [
            "SSS",
            "SCS",
            "SSS"
        ],
        {
            S: 'minecraft:cobblestone',
            C: 'minecraft:charcoal'
        }
    ).id("tweier:furnace"); // ② 修正id调用方式 + ③ 补全event上下文
    //篝火
    event.shaped(
        Item.of('minecraft:campfire',1),
        [
            " M ",
            "MSM",
            "XXX"
        ],
        {
            M:'minecraft:stick',
            S:'minecraft:coal',
            X:'minecraft:oak_log'
        }
    ).id("tweier:campfire");


    //堆肥桶
       event.shaped(
        Item.of('minecraft:composter',1),
        [
            "M M",
            "M M",
            "MBM"
        ],
        {
            M:'minecraft:oak_planks',
            B:'minecraft:oak_slab'
        }
    ).id("tweier:composter");

  //安山合金
  event.shaped(
    Item.of('create:andesite_alloy',1),
    [
        "TA ",
        "AT ",
        "   "
        

    ],{
        T:'minecraft:iron_nugget',
        A:'minecraft:andesite'
    }


  ).id("tweier:createandesite_alloy");
 
      //下界岩
      event.shaped(
        Item.of('minecraft:netherrack',1),[
            "FFF",
            "FFF",
            "FFF"
        ],{
            F:'minecraft:rotten_flesh'
        }
      ).id("tweier:netherrack")
      //岩浆桶
      event.shaped(
        Item.of('minecraft:lava_bucket',1),[
            "FFF",
            "FTF",
            "FFF"
        ],{
            F:'minecraft:netherrack',
            T:'minecraft:bucket'
        }
      ).id("tweier:lava")
});