/*ServerEvents.recipes(event =>{
    //1. 筛子（无中生有)
    /* 移除原版配方
    event.remove({id:'exdeorum:oak_sieve'});
    // 新增魔改有序合成（木镐剩余资源直接制作）
    event.shaped(Item.of('exdeorum:oak_sieve',1),[
        '   ',
        "WWW",
        "S S"
    ],{
        W:'minecraft:oak_planks',
        S: 'minecraft:stick'
    }).id("tweier:sieve");


    /*无序合成
    event.shapeless(Item.of('',数量),[
    "",
    "",
    ""
    ]);
    */
    /*熔炉
    event.smelting('输出物品','什么烧',经验,20*秒);
    */
    /*烟熏炉
    event.smoking('输出物品','什么烧',经验,20*秒);
    */
    /*高炉
    event.blasting('输出物品','什么烧',经验,20*秒);
    */
    /*萤火
    event.campfireCooking('输出物品','什么烧',经验,20*秒);
    */
    /*燃料
    Item.getItem('燃烧物品').burnTime=20*秒;*/
    /*锻造台
    event.smithing('minecraft:enchanting_table','第一个','第二个','输出');
    */
    /*切石基
    event.stonecutting('输出物品','输入物品');*/

//});