StartupEvents.registry("item",event =>{
    event.create("tweier:diamond","create:sequenced_assembly")
})
